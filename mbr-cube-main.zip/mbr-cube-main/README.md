# mbr-cube
An MBR (under 512 bytes) x86 assembly demo that shows a spinning rainbow 3D cube with detached faces.
![Image showcasing the MBR](https://i.imgur.com/TiNkNEC.png)
